# -*- coding: utf-8 -*-
from odoo.exceptions import ValidationError
from dateutil.relativedelta import relativedelta

from datetime import datetime,date
from odoo import models, fields, api

class RetenueType(models.TransientModel):
    _name = 'retenue.type'

class PartnerDetails(models.TransientModel):
    _name = 'partner.details'

    partner_ids= fields.Many2many('res.partner', default=lambda self: self.env['res.partner'].search(['|',('customer','=',True), ('supplier','=',True)]))
    date_from = fields.Date(string="Date From",default=lambda self: fields.Date.to_string(date.today().replace(day=1)))
    date_to = fields.Date(string="Date To", default=lambda self: fields.Date.to_string((datetime.now() + relativedelta(months=+1, day=1, days=-1)).date()))

    company_id= fields.Many2one('res.company', default=lambda self: self.env['res.company'].browse(self.env['res.company']._company_default_get('partner.details')).id)

    def GenererDetails(self):
        for rec in self:
            import datetime
            DATEFORMAT =  "%Y-%m-%d"
            today = date.today()
            current_date =today.strftime(DATEFORMAT)
            list =[]
            total = 0.0
            total_paid = 0.0
            total_reste = 0.0
            # partner_ids = self.env['res.partner'].search([('custoemr','=',True)])
            for partner in rec.partner_ids:
                total = 0.0
                total_paid = 0.0
                total_reste = 0.0
                start_date=datetime.datetime.strptime(str(rec.date_from), "%Y-%m-%d")
                end_date=datetime.datetime.strptime(str(rec.date_to), "%Y-%m-%d")
                date_from= start_date.replace(hour=1, minute=0)
                date_to = end_date.replace(hour=0, minute=0)
                sale_ids = self.env['sale.order'].search([('partner_id', '=', partner.id),('state', '=', 'sale'), ('confirmation_date','>=',date_from),('confirmation_date','<=',date_to)])
                purchase_ids = self.env['purchase.order'].search([('partner_id', '=', partner.id),('state', '=', 'purchase'), ('date_order_copy','>=',date_from),('date_order_copy','<=',date_to)])
                invoice_ids = self.env['account.invoice'].search([('partner_id', '=', partner.id),('date_invoice','>=',rec.date_from),('date_invoice','<=',rec.date_to),('state', 'in',( 'open','paid')),('origin', '=', False)])
                payment_ids = self.env['account.payment'].search([('partner_id', '=', partner.id),('state', 'not in',( 'draft','cancelled'))])

                if partner.customer == True:
                    for sale in sale_ids:
                        total += sale.amount_total
                else:
                    for purchase in purchase_ids:
                        total += purchase.amount_total
                    # total_reste += sale.resteApayer
                for inv in invoice_ids:
                    total += inv.amount_total
                    # total_reste += inv.residual
                for payment in payment_ids:
                    total_paid += payment.amount
                total_reste = total - total_paid
                if total_reste != 0.0:
                    detail_ids = self.env['partner.detail.line'].create({
                        "partner_id":partner.id,
                        "company_id":rec.company_id.id,
                        "total":total,
                        "total_paid":total_paid,
                        "total_reste":total_reste,
                    })
                    list.append(detail_ids.id)
            # raise ValidationError(str(list))
            detailS_ids = self.env['partner.details.model'].create({
                "company_id":rec.company_id.id,
                "line_details":[ (6, 0, list)],
                "date_from":date_from,
                "date_to":date_to,
            })
            return self.env.ref('account_due_list.rapport_etat_client').report_action(detailS_ids)


class PartnerDetailsLines(models.Model):
    _name = 'partner.detail.line'

    partner_id= fields.Many2one('res.partner')
    company_id= fields.Many2one('res.company', default=lambda self: self.env['res.company'].browse(self.env['res.company']._company_default_get('partner.detail.line')).id)

    total = fields.Float("")
    total_paid = fields.Float("")
    total_reste = fields.Float("")
class PartnerDetailModel(models.Model):
    _name = 'partner.details.model'
    company_id= fields.Many2one('res.company', default=lambda self: self.env['res.company'].browse(self.env['res.company']._company_default_get('partner.details.model')).id)
    line_details = fields.Many2many("partner.detail.line")
    date_from = fields.Date(string="Date From",default=lambda self: fields.Date.to_string(date.today().replace(day=1)))
    date_to = fields.Date(string="Date To", default=lambda self: fields.Date.to_string((datetime.now() + relativedelta(months=+1, day=1, days=-1)).date()))

class ResPartner(models.Model):
    _inherit = 'res.partner'

    solde_partner = fields.Float('', compute='get_total_solde')

    def get_total_solde(self):
        for rec in self:
            import datetime
            list =[]
            total = 0.0
            total_paid = 0.0
            total_reste = 0.0
            total = 0.0
            total_paid = 0.0
            total_reste = 0.0
            sale_ids = self.env['sale.order'].search([('partner_id', '=', rec.id),('state', '=', 'sale')])
            purchase_ids = self.env['purchase.order'].search([('partner_id', '=', rec.id),('state', '=', 'purchase')])
            invoice_ids = self.env['account.invoice'].search([('partner_id', '=', rec.id),('state', 'in',( 'open','paid')),('origin', '=', False)])
            payment_ids = self.env['account.payment'].search([('partner_id', '=', rec.id),('state', 'not in',( 'draft','cancelled'))])
            if rec.customer == True:
                for sale in sale_ids:
                    total += sale.amount_total
            else:
                for purchase in purchase_ids:
                    total += purchase.amount_total
                # total_reste += sale.resteApayer
            for inv in invoice_ids:
                total += inv.amount_total
                # total_reste += inv.residual
            for payment in payment_ids:
                total_paid += payment.amount
            rec.solde_partner = total - total_paid

class PaymentRestPaid(models.Model):
    _inherit = 'account.payment'

    solde_partner = fields.Float(related='partner_id.solde_partner')

class PurchaseRestPaid(models.Model):
    _inherit = 'purchase.order'

    solde_partner = fields.Float(related='partner_id.solde_partner')
class SaleRestPaid(models.Model):
    _inherit = 'sale.order'

    solde_partner = fields.Float(related='partner_id.solde_partner')
