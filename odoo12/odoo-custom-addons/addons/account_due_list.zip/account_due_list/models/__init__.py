# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl.html).

from . import account_move_line
from . import invoice_details
from . import stock_sale_alert
from . import partners_state
